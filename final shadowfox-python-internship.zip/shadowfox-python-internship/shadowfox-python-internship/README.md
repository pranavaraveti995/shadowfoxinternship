# ShadowFox Python Development Internship - Submission

| Level | Task | Folder / file |
|---|---|---|
| Task 1 (Beginner, 5 of 9 required) | All 9 sections completed | `task1_beginner/01_...09_*.py` |
| Task 2 (Intermediate, both) | Web Scraper + Hangman | `task2_intermediate/` |
| Task 3 (Advanced, 1 of 3) | Cricket Fielding Analysis | `task3_advanced/` |

```bash
pip install -r requirements.txt
python task1_beginner/03_list.py
python task2_intermediate/hangman.py
```

---
## Task 1 - Beginner

| # | File | What it does and the key idea |
|---|---|---|
| 1 | `01_variables.py` | `22/7` is a **float** (`/` is true division). `for = 4` raises **SyntaxError** because `for` is a reserved keyword. Simple Interest = P x R x T / 100. |
| 2 | `02_numbers.py` | `format(145, 'o')` -> `221` (**octal**, base 8). Pond area = 3.14 x 84^2 = 22155.84 m2 -> 31018 litres. Speed = 490 m / 420 s -> 1 m/s (decimals dropped with `int()`). |
| 3 | `03_list.py` | `len`, `extend`, `remove` + `insert(0, ..)`, re-inserting between two items, replacing a list, `sort()`. Bonus: new leader is **Cyborg**. |
| 4 | `04_if_condition.py` | BMI category with if/elif (uses `>=` boundaries so no value falls in a gap); city -> country lookup; same-country check. |
| 5 | `05_for_loop.py` | Dice simulation counting 6s, 1s and consecutive 6s; jumping-jack workout with yes/no validation and early exit via `return`. |
| 6 | `06_dictionary.py` | List of `(name, len)` tuples; trip-expense dictionaries, totals, who spent more, category with the biggest gap. |
| 7 | `07_file_handling.py` | Reads `student_marks.csv`, builds a dict, adds `total_marks` and `Average`, writes a report `.txt` and a new CSV. |
| 8 | `08_classes_objects.py` | `Avenger` class (name, age, gender, super power, weapon), getters, `is_leader()`. |
| 9 | `09_inheritance.py` | `MobilePhone` base class, `Apple` and `Samsung` child classes using `super().__init__()`, validated specs, call/picture methods. |

## Task 2 - Intermediate

**Web scraper (`web_scraper.py`)** - `requests` downloads the page, `BeautifulSoup` extracts title, meta description, headings, paragraphs, links and images; results saved as JSON and CSV. Error handling: automatic retries with back-off, timeouts, handling of HTTP errors / connection errors / non-HTML content, and a polite delay when following internal links (`--pages N`).
`python web_scraper.py https://shadowfox.in --pages 3`

**Hangman (`hangman.py`)** - random word from categories, ASCII gallows that grows with each wrong guess, input validation, `hint` command (reveals a letter, costs a life), win/loss checks, game loop, play-again with score.

## Task 3 - Advanced: Cricket Fielding Analysis (`task3_advanced/cricket_fielding_analysis.xlsx`)

* `Ball_by_Ball` - one row per ball with all 13 columns from the brief and drop-downs for Pick/Throw.
* `Performance_Matrix` - `COUNTIFS`/`SUMIFS` formulas count each action per player, then
  `PS = CP*1 + GT*1 + C*3 + DC*(-3) + ST*3 + RO*3 + MRO*(-2) + DH*2 + RS` (weights from the sample file).
  Also pick success %, catch conversion %, throw accuracy %, runs saved by innings phase, coach notes and a chart.
* `Formula_Check` - reproduces the 7 worked examples from `IPL_sample_data.xlsx` (10, 2, 11, 11, 6, 9, 9): all match.
* `build_cricket_workbook.py` regenerates the workbook.

## Things to do before submitting
1. **Task 3 data is illustrative (simulated).** Watch a real T20 innings, pick 3 fielders, and replace the rows in `Ball_by_Ball` with your own observations (rename the 3 players in `Performance_Matrix` A17:A19).
2. **Task 2:** confirm the ShadowFox website URL (`DEFAULT_URL` in `web_scraper.py`) and run the scraper against it on your own machine.
3. **Task 1.7:** the supplied `student_marks.csv` is a small sample; drop in the Kaggle file (same folder, same name) and rerun.
4. Push to GitHub and record the 3-5 minute explanation video (Google Drive link in the form).

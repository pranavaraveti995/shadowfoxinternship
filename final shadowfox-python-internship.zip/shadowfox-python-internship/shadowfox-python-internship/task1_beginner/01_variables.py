"""Task 1.1 - Variables"""
import keyword

# ---- Q1: pi = 22/7 and its data type ---------------------------------------
pi = 22 / 7
print("Q1) pi =", pi, "| type:", type(pi))          # <class 'float'>
# '/' is true division in Python 3, so the result is always a float.

# ---- Q2: a variable called `for` -------------------------------------------
# `for` is a reserved keyword, so the line below is a SyntaxError.
# We use exec() so the script can show the error without crashing.
try:
    exec("for = 4")
except SyntaxError as err:
    print("\nQ2) 'for = 4' ->", type(err).__name__, ":", err.msg)
print("    Is 'for' a keyword?", keyword.iskeyword("for"))
print("    All reserved keywords:", keyword.kwlist)
# Reason: keywords have a special meaning in the language grammar and cannot
# be used as identifiers. Use something like for_ or count instead.

# ---- Q3: Simple Interest = P x R x T / 100 ---------------------------------
principal = 10000      # P - principal amount
rate = 7.5             # R - rate of interest (% per year)
time = 3               # T - time in years
simple_interest = principal * rate * time / 100
print(f"\nQ3) P={principal}, R={rate}%, T={time} yrs -> Simple Interest = {simple_interest}")
print(f"    Total amount after {time} years = {principal + simple_interest}")

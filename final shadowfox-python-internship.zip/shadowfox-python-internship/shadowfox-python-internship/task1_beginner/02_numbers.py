"""Task 1.2 - Numbers"""

# ---- Q1: format() with 145 and 'o' ------------------------------------------
def format_number(number, spec):
    """Return number formatted using the given format specifier."""
    return format(number, spec)

print("Q1) format(145, 'o') =", format_number(145, "o"))
# 'o' = OCTAL (base 8). 145 = 2*64 + 2*8 + 1  ->  '221'.
# Other specifiers for comparison: 'b' binary, 'x' hex, 'e' scientific.
print("    binary:", format_number(145, "b"), "| hex:", format_number(145, "x"))

# ---- Q2: pond area + bonus ---------------------------------------------------
PI = 3.14
radius = 84                       # metres
area = PI * radius ** 2           # square metres
print(f"\nQ2) Pond area = {area:.2f} square metres")

litres_per_sq_m = 1.4
water = area * litres_per_sq_m
print("    Bonus - total water (no decimal point):", int(water), "litres")
# int() truncates 31018.176 -> 31018 (round() would give the same here).

# ---- Q3: speed in m/s -------------------------------------------------------
distance = 490                    # metres
time_seconds = 7 * 60             # 7 minutes -> 420 seconds
speed = distance / time_seconds   # 1.1666... m/s
print("\nQ3) Speed (no decimal point):", int(speed), "m/s")
print(f"    (exact value = {speed:.4f} m/s; int() truncates the decimals)")

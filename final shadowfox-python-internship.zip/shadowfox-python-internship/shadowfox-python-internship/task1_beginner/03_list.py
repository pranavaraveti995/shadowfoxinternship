"""Task 1.3 - List operations on the Justice League"""

justice_league = ["Superman", "Batman", "Wonder Woman", "Flash", "Aquaman", "Green Lantern"]
print("Start           :", justice_league)

# 1. Number of members
print("1. Members      :", len(justice_league))

# 2. Batman recruits Batgirl and Nightwing
justice_league.extend(["Batgirl", "Nightwing"])
print("2. Recruited    :", justice_league)

# 3. Wonder Woman becomes leader -> move to the beginning
justice_league.remove("Wonder Woman")
justice_league.insert(0, "Wonder Woman")
print("3. New leader   :", justice_league)

# 4. Separate Aquaman and Flash by putting Green Lantern between them
hero = "Green Lantern"                       # (Superman would work too)
justice_league.remove(hero)
flash_pos = justice_league.index("Flash")
aqua_pos = justice_league.index("Aquaman")
# insert right after whichever of the two comes first
justice_league.insert(min(flash_pos, aqua_pos) + 1, hero)
print("4. Separated    :", justice_league)

# 5. Crisis - replace with a brand new team
justice_league = ["Cyborg", "Shazam", "Hawkgirl", "Martian Manhunter", "Green Arrow"]
print("5. New team     :", justice_league)

# 6. Sort alphabetically; index 0 becomes the leader
justice_league.sort()
print("6. Sorted       :", justice_league)
print("   New leader   :", justice_league[0])

# BONUS prediction: alphabetical order -> 'Cyborg' (C) comes before
# 'Green Arrow' (G), 'Hawkgirl' (H), 'Martian Manhunter' (M), 'Shazam' (S).

"""Task 1.4 - If conditions (BMI, city->country, same country)"""

countries = {
    "Australia": ["Sydney", "Melbourne", "Brisbane", "Perth"],
    "UAE":       ["Dubai", "Abu Dhabi", "Sharjah", "Ajman"],
    "India":     ["Mumbai", "Bangalore", "Chennai", "Delhi"],
}

def bmi_category(height_m, weight_kg):
    bmi = weight_kg / (height_m ** 2)
    # The brief leaves gaps (e.g. 29.5), so we use >= boundaries that cover every value.
    if bmi >= 30:
        return bmi, "Obesity"
    elif bmi >= 25:
        return bmi, "Overweight"
    elif bmi >= 18.5:
        return bmi, "Normal"
    else:
        return bmi, "Underweight"

def find_country(city):
    city = city.strip().title()
    for country, cities in countries.items():
        if city in cities:
            return country
    return None

def q1_bmi():
    print("--- Q1: BMI category ---")
    height = float(input("Enter height in meters: "))
    weight = float(input("Enter weight in kilograms: "))
    bmi, category = bmi_category(height, weight)
    print(f"BMI = {bmi:.1f}")
    print(f'Output: "{category}"')

def q2_city_country():
    print("--- Q2: Which country is the city in? ---")
    city = input("Enter a city name: ")
    country = find_country(city)
    if country:
        print(f'Output: "{city.strip().title()} is in {country}"')
    else:
        print("Output: City not found in our list")

def q3_same_country():
    print("--- Q3: Same country? ---")
    c1 = input("Enter the first city: ")
    c2 = input("Enter the second city: ")
    k1, k2 = find_country(c1), find_country(c2)
    if k1 is None or k2 is None:
        print("Output: One of the cities is not in our list")
    elif k1 == k2:
        print(f'Output: "Both cities are in {k1}"')
    else:
        print('Output: "They don\'t belong to the same country"')

if __name__ == "__main__":
    q1_bmi()
    print()
    q2_city_country()
    print()
    q3_same_country()

"""Task 1.5 - For loops (dice statistics + jumping jacks)"""
import random

# ---------------------------------------------------------------------------
# Q1: roll a six-sided die 50 times
# ---------------------------------------------------------------------------
def dice_simulation(rolls=50):
    sixes = ones = double_sixes = 0
    previous = None
    history = []
    for _ in range(rolls):
        roll = random.randint(1, 6)
        history.append(roll)
        if roll == 6:
            sixes += 1
        if roll == 1:
            ones += 1
        if roll == 6 and previous == 6:       # two 6s back-to-back
            double_sixes += 1
        previous = roll
    print("Rolls            :", history)
    print("Number of 6s     :", sixes)
    print("Number of 1s     :", ones)
    print("Two 6s in a row  :", double_sixes)

# ---------------------------------------------------------------------------
# Q2: 100 jumping jacks, 10 per set
# ---------------------------------------------------------------------------
def ask_yes_no(question):
    while True:
        answer = input(question).strip().lower()
        if answer in ("yes", "y"):
            return True
        if answer in ("no", "n"):
            return False
        print("Please answer yes/y or no/n.")

def jumping_jacks(target=100, per_set=10):
    done = 0
    for _ in range(target // per_set):
        print(f"Do {per_set} jumping jacks!")
        done += per_set
        if done == target:
            print("Congratulations! You completed the workout")
            return
        if ask_yes_no("Are you tired? "):
            if ask_yes_no("Do you want to skip the remaining sets? "):
                print(f"You completed a total of {done} jumping jacks.")
                return
        print(f"{target - done} jumping jacks remaining.")

if __name__ == "__main__":
    print("--- Q1: Dice ---")
    dice_simulation()
    print("\n--- Q2: Jumping jacks ---")
    jumping_jacks()

"""Task 1.6 - Lists of tuples and dictionaries"""

# ---- Q1: friends and name lengths ------------------------------------------
friends = ["Aditya", "Priya", "Rahul", "Sneha", "Karthik", "Meera"]
friend_lengths = [(name, len(name)) for name in friends]
print("Q1) Friend tuples:", friend_lengths)          # e.g. ('Aditya', 6)

# ---- Q2: trip expenses ------------------------------------------------------
your_expenses = {"Hotel": 1200, "Food": 800, "Transportation": 500,
                 "Attractions": 300, "Miscellaneous": 200}
partner_expenses = {"Hotel": 1000, "Food": 900, "Transportation": 600,
                    "Attractions": 400, "Miscellaneous": 150}

your_total = sum(your_expenses.values())
partner_total = sum(partner_expenses.values())
print(f"\nQ2) Your total    : {your_total}")
print(f"    Partner total : {partner_total}")

if your_total > partner_total:
    print(f"    You spent more overall (by {your_total - partner_total}).")
elif partner_total > your_total:
    print(f"    Your partner spent more overall (by {partner_total - your_total}).")
else:
    print("    You both spent exactly the same.")

# Category with the biggest (absolute) difference
differences = {cat: abs(your_expenses[cat] - partner_expenses[cat]) for cat in your_expenses}
biggest = max(differences, key=differences.get)
print(f"    Biggest difference: {biggest} -> {differences[biggest]}")
print("    All differences  :", differences)

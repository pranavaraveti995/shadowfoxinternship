"""Task 1.7 - File handling with student_marks.csv

Steps required by the brief:
  1. open the file in read mode
  2. build a dictionary from the data
  3. add total_marks
  4. add Average
  5. write everything to a new file (and a new CSV)

Works with the Kaggle 'studentmarks' file too: every column whose values are all
numbers is treated as a subject mark, except the ones listed in ID_COLUMNS.
"""
import csv
from pathlib import Path

HERE = Path(__file__).parent
INPUT_FILE = HERE / "student_marks.csv"
OUTPUT_CSV = HERE / "student_marks_with_totals.csv"
OUTPUT_TXT = HERE / "student_marks_report.txt"
ID_COLUMNS = {"id", "roll", "roll_no", "student_id", "rollno", "sno", "s.no", "no"}

def is_number(text):
    try:
        float(text)
        return True
    except (TypeError, ValueError):
        return False

# 1 & 2: open in read mode, build dictionary {name: {column: value}}
students = {}
with open(INPUT_FILE, "r", newline="") as f:
    reader = csv.DictReader(f)
    columns = reader.fieldnames
    rows = list(reader)

name_col = columns[0] if "Name" not in columns else "Name"
subject_cols = [c for c in columns
                if c != name_col and c.strip().lower() not in ID_COLUMNS
                and all(is_number(r[c]) for r in rows)]

for row in rows:
    students[row[name_col]] = dict(row)

# 3 & 4: add total_marks and Average
for name, record in students.items():
    marks = [float(record[c]) for c in subject_cols]
    record["total_marks"] = sum(marks)
    record["Average"] = round(sum(marks) / len(marks), 2)

# 5a: write the information to a new text file
with open(OUTPUT_TXT, "w") as f:
    for name, record in students.items():
        f.write(f"{name}: total = {record['total_marks']:.0f}, average = {record['Average']}\n")

# 5b / Q2: write a new CSV with the new columns
out_columns = list(columns) + ["total_marks", "Average"]
with open(OUTPUT_CSV, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=out_columns)
    writer.writeheader()
    writer.writerows(students.values())

print("Subjects used :", subject_cols)
for name, record in students.items():
    print(f"{name:<10} total={record['total_marks']:<6.0f} average={record['Average']}")
print(f"\nWrote {OUTPUT_TXT.name} and {OUTPUT_CSV.name}")

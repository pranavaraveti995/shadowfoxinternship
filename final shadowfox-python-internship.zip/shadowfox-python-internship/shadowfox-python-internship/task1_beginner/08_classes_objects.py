"""Task 1.8 - Classes and Objects: The Avengers"""

class Avenger:
    def __init__(self, name, age, gender, super_power, weapon, leader=False):
        self.name = name
        self.age = age
        self.gender = gender
        self.super_power = super_power
        self.weapon = weapon
        self._leader = leader

    # --- getter methods -------------------------------------------------
    def get_name(self):        return self.name
    def get_age(self):         return self.age
    def get_gender(self):      return self.gender
    def get_super_power(self): return self.super_power
    def get_weapon(self):      return self.weapon

    def get_info(self):
        return (f"Name: {self.name} | Age: {self.age} | Gender: {self.gender} | "
                f"Super power: {self.super_power} | Weapon: {self.weapon}")

    def is_leader(self):
        return self._leader

    def __str__(self):
        return self.get_info()

# NOTE: ages are approximate / illustrative (they differ between comics and films).
super_heroes = ["Captain America", "Iron Man", "Black Widow", "Hulk", "Thor", "Hawkeye"]
ages    = [105, 48, 35, 49, 1500, 41]
genders = ["Male", "Male", "Female", "Male", "Male", "Male"]
powers  = ["Super strength", "Technology", "Superhuman", "Unlimited strength",
           "Super energy", "Fighting skills"]
weapons = ["Shield", "Armor", "Batons", "No weapon", "Mjolnir", "Bow and arrows"]

avengers = [
    Avenger(n, a, g, p, w, leader=(n == "Captain America"))
    for n, a, g, p, w in zip(super_heroes, ages, genders, powers, weapons)
]

for hero in avengers:
    print(hero.get_info())
    print(f"   -> Is {hero.get_name()} a leader? {'Yes' if hero.is_leader() else 'No'}")

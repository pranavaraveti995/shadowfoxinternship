"""Task 1.9 - Inheritance: MobilePhone -> Apple, Samsung"""

class MobilePhone:
    SCREEN_TYPE = "Touch Screen"
    NETWORKS = ("4G", "5G")
    FRONT_CAMERAS = ("5MP", "8MP", "12MP", "16MP")
    REAR_CAMERAS = ("8MP", "12MP", "16MP", "32MP", "48MP")
    RAM_OPTIONS = ("2GB", "3GB", "4GB")
    STORAGE_OPTIONS = ("16GB", "32GB", "64GB")

    def __init__(self, network_type, dual_sim, front_camera, rear_camera, ram, storage):
        for value, options, label in [
            (network_type, self.NETWORKS, "network type"),
            (front_camera, self.FRONT_CAMERAS, "front camera"),
            (rear_camera, self.REAR_CAMERAS, "rear camera"),
            (ram, self.RAM_OPTIONS, "RAM"),
            (storage, self.STORAGE_OPTIONS, "storage"),
        ]:
            if value not in options:
                raise ValueError(f"Invalid {label} '{value}'. Choose from {options}")
        self.screen_type = self.SCREEN_TYPE
        self.network_type = network_type
        self.dual_sim = dual_sim
        self.front_camera = front_camera
        self.rear_camera = rear_camera
        self.ram = ram
        self.storage = storage

    def make_call(self, number):
        return f"{self.brand} is calling {number}..."

    def receive_call(self, caller):
        return f"{self.brand} is receiving a call from {caller}."

    def take_a_picture(self, camera="rear"):
        mp = self.rear_camera if camera == "rear" else self.front_camera
        return f"{self.brand} took a picture with the {camera} camera ({mp})."

    brand = "Generic phone"

    def specs(self):
        return (f"{self.brand}: {self.screen_type}, {self.network_type}, "
                f"DualSIM={self.dual_sim}, Front={self.front_camera}, "
                f"Rear={self.rear_camera}, RAM={self.ram}, Storage={self.storage}")


class Apple(MobilePhone):
    brand = "Apple iPhone"
    def __init__(self, model, *args, **kwargs):
        super().__init__(*args, **kwargs)       # call parent constructor
        self.model = model
        self.os = "iOS"

    def face_id_unlock(self):
        return f"{self.model} unlocked with Face ID."


class Samsung(MobilePhone):
    brand = "Samsung Galaxy"
    def __init__(self, model, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.model = model
        self.os = "Android (One UI)"

    def use_split_screen(self):
        return f"{self.model} is running two apps in split screen."


if __name__ == "__main__":
    apples = [
        Apple("iPhone A", "5G", False, "12MP", "48MP", "4GB", "64GB"),
        Apple("iPhone B", "4G", False, "8MP", "12MP", "3GB", "32GB"),
    ]
    samsungs = [
        Samsung("Galaxy A", "5G", True, "16MP", "32MP", "4GB", "64GB"),
        Samsung("Galaxy B", "4G", True, "5MP", "8MP", "2GB", "16GB"),
        Samsung("Galaxy C", "4G", True, "8MP", "16MP", "3GB", "32GB"),
    ]
    for phone in apples + samsungs:
        print(phone.specs())
    print()
    print(apples[0].make_call("9876543210"))
    print(apples[0].face_id_unlock())
    print(samsungs[0].receive_call("Mom"))
    print(samsungs[0].take_a_picture("front"))
    print(samsungs[1].use_split_screen())
    print("\nIsinstance(apples[0], MobilePhone):", isinstance(apples[0], MobilePhone))
    try:
        Apple("Bad", "3G", False, "8MP", "12MP", "3GB", "32GB")
    except ValueError as e:
        print("Validation works ->", e)

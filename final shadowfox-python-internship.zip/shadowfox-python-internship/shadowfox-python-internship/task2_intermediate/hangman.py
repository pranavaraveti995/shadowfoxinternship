"""
Task 2.2 - Hangman (text based, with visual progress and hints)

Features: random word from categories, ASCII hangman, input validation,
hint system (category + optional letter reveal that costs one life),
win/loss detection, game loop and play again.
"""
import random

WORDS = {
    "Programming": ["python", "variable", "function", "loop", "dictionary", "inheritance", "compiler"],
    "Cricket":     ["wicket", "boundary", "bowler", "stumping", "fielder", "innings", "umpire"],
    "Animals":     ["elephant", "giraffe", "dolphin", "penguin", "kangaroo", "cheetah"],
    "Space":       ["galaxy", "asteroid", "telescope", "satellite", "nebula", "astronaut"],
}
MAX_ATTEMPTS = 6

STAGES = [
    """
      -----
      |   |
          |
          |
          |
          |
    =========""",
    """
      -----
      |   |
      O   |
          |
          |
          |
    =========""",
    """
      -----
      |   |
      O   |
      |   |
          |
          |
    =========""",
    """
      -----
      |   |
      O   |
     /|   |
          |
          |
    =========""",
    """
      -----
      |   |
      O   |
     /|\\  |
          |
          |
    =========""",
    """
      -----
      |   |
      O   |
     /|\\  |
     /    |
          |
    =========""",
    """
      -----
      |   |
      O   |
     /|\\  |
     / \\  |
          |
    =========""",
]


def choose_word():
    category = random.choice(list(WORDS))
    return category, random.choice(WORDS[category])


def display(word, guessed, wrong, category):
    print(STAGES[len(wrong)])
    print(f"\nCategory : {category}")
    print("Word     :", " ".join(ch if ch in guessed else "_" for ch in word))
    print("Wrong    :", " ".join(sorted(wrong)) or "-")
    print(f"Lives left: {MAX_ATTEMPTS - len(wrong)}")


def get_guess(guessed, wrong):
    """Prompt until a valid new letter (or the word 'hint') is entered."""
    while True:
        text = input("\nGuess a letter (or type 'hint'): ").strip().lower()
        if text == "hint":
            return "hint"
        if len(text) != 1 or not text.isalpha():
            print("Please enter exactly ONE letter (a-z).")
        elif text in guessed or text in wrong:
            print(f"You already tried '{text}'.")
        else:
            return text


def give_hint(word, guessed, wrong):
    """Reveal one hidden letter; costs one life (adds a 'wrong' mark)."""
    hidden = [c for c in word if c not in guessed]
    if len(set(hidden)) <= 1:
        print("Hint refused - that would just give away the word!")
        return
    if len(wrong) >= MAX_ATTEMPTS - 1:
        print("You can't afford a hint on your last life!")
        return
    letter = random.choice(hidden)
    guessed.add(letter)
    wrong.add(f"*{letter}")            # '*' marks a life spent on a hint
    print(f"Hint: the word contains '{letter}'. (cost: 1 life)")


def play_round():
    category, word = choose_word()
    guessed, wrong = set(), set()
    print(f"\nA {len(word)}-letter word from the category '{category}'. Good luck!")

    while True:
        display(word, guessed, wrong, category)
        if all(ch in guessed for ch in word):
            print(f"\n🎉 You won! The word was '{word}'.")
            return True
        if len(wrong) >= MAX_ATTEMPTS:
            print(f"\n💀 You lost. The word was '{word}'.")
            return False

        guess = get_guess(guessed, wrong)
        if guess == "hint":
            give_hint(word, guessed, wrong)
        elif guess in word:
            guessed.add(guess)
            print(f"Nice! '{guess}' is in the word.")
        else:
            wrong.add(guess)
            print(f"Sorry, '{guess}' is not in the word.")


def main():
    wins = games = 0
    print("=== HANGMAN ===")
    while True:
        games += 1
        wins += play_round()
        print(f"Score: {wins} won / {games} played")
        again = input("\nPlay again? (y/n): ").strip().lower()
        if again not in ("y", "yes"):
            print("Thanks for playing!")
            break


if __name__ == "__main__":
    main()

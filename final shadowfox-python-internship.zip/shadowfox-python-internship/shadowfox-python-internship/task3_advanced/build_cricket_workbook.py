"""
Task 3.1 - Cricket Fielding Analysis: builds cricket_fielding_analysis.xlsx

Sheets
  Instructions       - legend, weights explanation, how to enter data
  Ball_by_Ball       - one row per ball (13 columns required by the brief)
  Performance_Matrix - formulas (COUNTIFS/SUMIFS) -> Performance Score + insights + chart
  Formula_Check      - re-computes the 7 worked examples from IPL_sample_data.xlsx

IMPORTANT: the ball-by-ball rows generated here are ILLUSTRATIVE (a seeded random
simulation of one 20-over innings with 3 tracked fielders). They are NOT from a real
match. Replace the rows in Ball_by_Ball with your own observed data; every number in
Performance_Matrix recalculates automatically.
"""
import random
from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

random.seed(2367)
FONT = "Arial"
BLUE = Font(name=FONT, color="0000FF")
BOLD = Font(name=FONT, bold=True)
BASE = Font(name=FONT)
HEAD_FILL = PatternFill("solid", fgColor="1F3864")
HEAD_FONT = Font(name=FONT, bold=True, color="FFFFFF")
YELLOW = PatternFill("solid", fgColor="FFFF99")
GREY = PatternFill("solid", fgColor="F2F2F2")
thin = Side(style="thin", color="BFBFBF")
BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)

PLAYERS = {   # name -> (role, positions)
    "Player A": ("keeper", ["Wicket keeper"]),
    "Player B": ("inner",  ["Point", "Cover", "Short mid wicket", "Mid off"]),
    "Player C": ("outer",  ["Long on", "Deep mid wicket", "Long off", "Third man"]),
}
# (weight, pick, throw, runs, description)
EVENTS = {
    "keeper": [
        (28, "Y", "", 0, "Collects cleanly behind the stumps"),
        (14, "Y", "Y", 0, "Clean take, good throw back to bowler"),
        (6,  "C", "", 0, "Takes a catch behind the wicket"),
        (2,  "DC", "", -1, "Drops a regulation edge"),
        (4,  "S", "", 0, "Stumping - batter out of crease"),
        (4,  "N", "", -1, "Fumbles, byes conceded"),
        (2,  "Y", "RO", 0, "Run out with a quick gather and break"),
        (3,  "Y", "MR", 0, "Misses run-out chance"),
        (2,  "Y", "DH", 1, "Direct hit, batter just safe"),
    ],
    "inner": [
        (30, "Y", "", 1, "Clean stop saves a single"),
        (16, "Y", "Y", 1, "Clean pick and good throw"),
        (5,  "C", "", 0, "Takes a sharp catch"),
        (3,  "DC", "", -1, "Drops a chance"),
        (6,  "N", "", -1, "Fumbles, extra run taken"),
        (4,  "Y", "N", -1, "Clean pick but wild throw, overthrow"),
        (3,  "Y", "RO", 0, "Direct throw, run out"),
        (4,  "Y", "MR", 0, "Throw misses, run out chance lost"),
        (6,  "Y", "DH", 2, "Direct hit, saves two runs"),
    ],
    "outer": [
        (24, "Y", "", 1, "Cuts off a boundary and saves a run"),
        (18, "Y", "Y", 2, "Dives, clean pick, good return saves 2"),
        (6,  "C", "", 0, "Catch in the deep"),
        (4,  "DC", "", -2, "Drops a catch on the rope"),
        (6,  "N", "", -1, "Fumbles in the deep"),
        (4,  "Y", "N", -1, "Poor throw lets batters take an extra"),
        (2,  "Y", "RO", 0, "Hits the stumps, run out"),
        (3,  "Y", "MR", 0, "Misses the stumps"),
        (4,  "Y", "DH", 1, "Direct hit, batter safe"),
    ],
}

def build_rows(overs=20):
    rows = []
    names = list(PLAYERS)
    for over in range(overs):
        for ball in range(1, 7):
            who = random.choices(names + [None], weights=[20, 26, 26, 28])[0]
            base = ["ILLUSTRATIVE-01", 1, "Fielding Team"]
            if who is None:                         # another fielder / no fielding action
                rows.append(base + [None, round(over + ball / 10, 1), None, None, None, None, None,
                                    None, over + 1, "Venue (edit)", "Stadium (edit)"])
                continue
            role, positions = PLAYERS[who]
            weights = [e[0] for e in EVENTS[role]]
            _, pick, throw, runs, desc = random.choices(EVENTS[role], weights=weights)[0]
            position = positions[0] if role == "keeper" else random.choice(positions)
            rows.append(base + [who, round(over + ball / 10, 1), position, desc, pick, throw or None,
                                runs, over + 1, "Venue (edit)", "Stadium (edit)"])
    return rows

HEADERS = ["Match No.", "Innings", "Team", "Player Name", "BallCount", "Position",
           "Short Description", "Pick", "Throw", "Runs", "Overcount", "Venue", "Stadium"]
LAST = 1000   # formulas look at rows 2..1000 so you can paste a longer match

def style_header(ws, row, ncols, start_col=1):
    for c in range(start_col, start_col + ncols):
        cell = ws.cell(row=row, column=c)
        cell.font, cell.fill, cell.border = HEAD_FONT, HEAD_FILL, BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

wb = Workbook()

# ------------------------------------------------------------------ Ball_by_Ball
ws = wb.active
ws.title = "Ball_by_Ball"
ws.append(HEADERS)
style_header(ws, 1, len(HEADERS))
for r in build_rows():
    ws.append(r)
for row in ws.iter_rows(min_row=2, max_row=ws.max_row):
    for cell in row:
        cell.font, cell.border = BASE, BORDER
widths = [17, 9, 15, 13, 11, 18, 44, 7, 8, 7, 11, 15, 16]
for i, w in enumerate(widths, 1):
    ws.column_dimensions[chr(64 + i)].width = w
ws.freeze_panes = "A2"
ws.auto_filter.ref = f"A1:M{ws.max_row}"
dv_pick = DataValidation(type="list", formula1='"Y,N,C,DC,S"', allow_blank=True)
dv_throw = DataValidation(type="list", formula1='"Y,N,DH,RO,MR"', allow_blank=True)
ws.add_data_validation(dv_pick); ws.add_data_validation(dv_throw)
dv_pick.add(f"H2:H{LAST}"); dv_throw.add(f"I2:I{LAST}")

# ------------------------------------------------------------------ Performance_Matrix
pm = wb.create_sheet("Performance_Matrix")
pm["A1"] = "Fielding Performance Matrix"; pm["A1"].font = Font(name=FONT, bold=True, size=14)
pm["A2"] = ("NOTE: Ball_by_Ball currently holds ILLUSTRATIVE simulated data (not a real match). "
            "Replace it with your observed data and this sheet recalculates.")
pm["A2"].font = Font(name=FONT, italic=True, color="C00000")

pm["A4"], pm["B4"], pm["C4"] = "Metric", "Weight", "Meaning"
style_header(pm, 4, 7)
pm.merge_cells("C4:G4")
weights = [("CP", "Clean Pick (Pick = Y)", 1), ("GT", "Good Throw (Throw = Y)", 1),
           ("C", "Catch (Pick = C)", 3), ("DC", "Dropped Catch (Pick = DC)", -3),
           ("ST", "Stumping (Pick = S)", 3), ("RO", "Run Out (Throw = RO)", 3),
           ("MRO", "Missed Run Out (Throw = MR)", -2), ("DH", "Direct Hit (Throw = DH)", 2)]
for i, (code, meaning, w) in enumerate(weights, start=5):
    pm.cell(i, 1, code).font = BOLD
    c = pm.cell(i, 2, w); c.font, c.fill = BLUE, YELLOW
    pm.cell(i, 3, meaning).font = BASE
    pm.merge_cells(start_row=i, start_column=3, end_row=i, end_column=7)
    for col in range(1, 8):
        pm.cell(i, col).border = BORDER
pm["A13"] = "RS"; pm["B13"] = "x1"; pm["C13"] = "Runs Saved (+) / conceded (-): added as is"
pm.merge_cells("C13:G13")
for col in "ABC":
    pm[f"{col}13"].font = BASE
for col in range(1, 8):
    pm.cell(13, col).border = BORDER
pm["I4"] = "Weights (yellow, blue text) come from IPL_sample_data.xlsx. DC and MRO are stored as negatives, so PS = sum(count x weight) + RS."
pm["I4"].font = Font(name=FONT, italic=True)

H = 16
cols = ["Player Name", "CP", "GT", "C", "DC", "ST", "RO", "MRO", "DH", "RS", "PS",
        "Fumbles", "Bad Throws", "Pick Success %", "Catch Conversion %", "Throw Accuracy %", "Coach notes"]
for i, name in enumerate(cols, 1):
    pm.cell(H, i, name)
style_header(pm, H, len(cols))
rng = lambda col: f"Ball_by_Ball!${col}$2:${col}${LAST}"
for r, player in enumerate(PLAYERS, start=H + 1):
    pm.cell(r, 1, player).font = BLUE
    f = {
        2:  f'=COUNTIFS({rng("D")},$A{r},{rng("H")},"Y")',
        3:  f'=COUNTIFS({rng("D")},$A{r},{rng("I")},"Y")',
        4:  f'=COUNTIFS({rng("D")},$A{r},{rng("H")},"C")',
        5:  f'=COUNTIFS({rng("D")},$A{r},{rng("H")},"DC")',
        6:  f'=COUNTIFS({rng("D")},$A{r},{rng("H")},"S")',
        7:  f'=COUNTIFS({rng("D")},$A{r},{rng("I")},"RO")',
        8:  f'=COUNTIFS({rng("D")},$A{r},{rng("I")},"MR")',
        9:  f'=COUNTIFS({rng("D")},$A{r},{rng("I")},"DH")',
        10: f'=SUMIFS({rng("J")},{rng("D")},$A{r})',
        11: f'=B{r}*$B$5+C{r}*$B$6+D{r}*$B$7+E{r}*$B$8+F{r}*$B$9+G{r}*$B$10+H{r}*$B$11+I{r}*$B$12+J{r}',
        12: f'=COUNTIFS({rng("D")},$A{r},{rng("H")},"N")',
        13: f'=COUNTIFS({rng("D")},$A{r},{rng("I")},"N")',
        14: f'=IF(B{r}+L{r}=0,"n/a",B{r}/(B{r}+L{r}))',
        15: f'=IF(D{r}+E{r}=0,"n/a",D{r}/(D{r}+E{r}))',
        16: f'=IF(C{r}+I{r}+G{r}+M{r}+H{r}=0,"n/a",(C{r}+I{r}+G{r})/(C{r}+I{r}+G{r}+M{r}+H{r}))',
        17: (f'=TRIM(IF(E{r}>0,"Work on catching. ","")&IF(L{r}>=2,"Reduce fumbles. ","")'
             f'&IF(M{r}+H{r}>=2,"Sharpen throwing. ","")&IF(K{r}=MAX($K${H+1}:$K${H+len(PLAYERS)}),"Highest PS of the group. ","")'
             f'&IF(AND(E{r}=0,L{r}<2,M{r}+H{r}<2),"Clean, reliable fielding.",""))'),
    }
    for c, formula in f.items():
        pm.cell(r, c, formula)
    for c in range(1, len(cols) + 1):
        cell = pm.cell(r, c); cell.border = BORDER
        if c > 1: cell.font = BASE
        if c in (14, 15, 16): cell.number_format = "0.0%"
    pm.cell(r, 11).font = BOLD; pm.cell(r, 11).fill = GREY
T = H + 1 + len(PLAYERS)
pm.cell(T, 1, "Team (tracked 3)").font = BOLD
for c in range(2, 14):
    L = chr(64 + c)
    pm.cell(T, c, f"=SUM({L}{H+1}:{L}{T-1})").font = BOLD
for c in range(1, 18):
    pm.cell(T, c).border = BORDER
pm.cell(T + 1, 1, "Top performer").font = BOLD
pm.cell(T + 1, 2, f"=INDEX(A{H+1}:A{T-1},MATCH(MAX(K{H+1}:K{T-1}),K{H+1}:K{T-1},0))").font = BASE
pm.cell(T + 2, 1, "Rates: Pick Success = CP/(CP+Fumbles); Catch Conversion = C/(C+DC); Throw Accuracy = (GT+DH+RO)/(GT+DH+RO+Bad Throws+MRO).").font = Font(name=FONT, italic=True)

# Phase analysis: runs saved by phase of the innings
P = T + 5
pm.cell(P - 1, 1, "Runs saved/conceded by phase of the innings").font = BOLD
for i, name in enumerate(["Player Name", "Powerplay (ov 1-6)", "Middle (ov 7-15)", "Death (ov 16-20)"], 1):
    pm.cell(P, i, name)
style_header(pm, P, 4)
for r, player in enumerate(PLAYERS, start=P + 1):
    pm.cell(r, 1, f"=A{H + r - P}").font = BASE
    for c, (lo, hi) in zip((2, 3, 4), ((1, 6), (7, 15), (16, 20))):
        pm.cell(r, c, f'=SUMIFS({rng("J")},{rng("D")},$A{r},{rng("K")},">={lo}",{rng("K")},"<={hi}")').font = BASE
    for c in range(1, 5): pm.cell(r, c).border = BORDER

chart = BarChart(); chart.type = "col"; chart.title = "Performance Score (PS) by player"
chart.y_axis.title = "PS"; chart.x_axis.title = "Player"
chart.add_data(Reference(pm, min_col=11, min_row=H, max_row=T - 1), titles_from_data=True)
chart.set_categories(Reference(pm, min_col=1, min_row=H + 1, max_row=T - 1))
chart.legend = None; chart.height, chart.width = 8, 14
pm.add_chart(chart, f"F{P - 1}")

pm.column_dimensions["A"].width = 19
for c in "CDEFGHIJKLMNOP": pm.column_dimensions[c].width = 11
pm.column_dimensions["N"].width = 14; pm.column_dimensions["O"].width = 18
pm.column_dimensions["P"].width = 16; pm.column_dimensions["Q"].width = 52
pm.freeze_panes = "B5"

# ------------------------------------------------------------------ Formula_Check
fc = wb.create_sheet("Formula_Check")
fc["A1"] = "Formula validation against the 7 worked examples in IPL_sample_data.xlsx"
fc["A1"].font = Font(name=FONT, bold=True, size=12)
fc["A2"] = "Counts (blue) are copied from the sample performance matrix; PS is recomputed with the weights in Performance_Matrix."
fc["A2"].font = Font(name=FONT, italic=True)
hdr = ["Player Name", "CP", "GT", "C", "DC", "ST", "RO", "MRO", "DH", "RS", "PS (formula)", "PS (sample)", "Match?"]
for i, h in enumerate(hdr, 1): fc.cell(4, i, h)
style_header(fc, 4, len(hdr))
sample = [("Rilee russouw", 2, 1, 1, 0, 0, 0, 0, 1, 2, 10), ("Phil Salt", 1, 2, 0, 1, 0, 1, 0, 0, -1, 2),
          ("Yash Dhull", 3, 1, 2, 0, 0, 0, 1, 0, 3, 11), ("Axer Patel", 2, 3, 1, 0, 1, 0, 0, 0, 0, 11),
          ("Lalit yadav", 1, 2, 1, 0, 0, 0, 0, 1, -2, 6), ("Aman Khan", 4, 1, 0, 0, 0, 1, 0, 0, 1, 9),
          ("Kuldeep yadav", 3, 0, 1, 1, 0, 0, 0, 1, 4, 9)]
for r, row in enumerate(sample, start=5):
    for c, v in enumerate(row[:10], 1):
        cell = fc.cell(r, c, v); cell.font = BLUE if c > 1 else BASE
    fc.cell(r, 11, f"=B{r}*Performance_Matrix!$B$5+C{r}*Performance_Matrix!$B$6+D{r}*Performance_Matrix!$B$7"
                   f"+E{r}*Performance_Matrix!$B$8+F{r}*Performance_Matrix!$B$9+G{r}*Performance_Matrix!$B$10"
                   f"+H{r}*Performance_Matrix!$B$11+I{r}*Performance_Matrix!$B$12+J{r}")
    fc.cell(r, 12, row[10]).font = BLUE
    fc.cell(r, 13, f'=IF(K{r}=L{r},"OK","CHECK")')
    for c in range(1, 14):
        fc.cell(r, c).border = BORDER
        if c in (11, 13): fc.cell(r, c).font = BASE
fc.column_dimensions["A"].width = 18
for c in "BCDEFGHIJKLM": fc.column_dimensions[c].width = 12

# ------------------------------------------------------------------ Instructions
ins = wb.create_sheet("Instructions", 0)
lines = [
    ("Cricket Fielding Analysis - ShadowFox Python Internship, Task 3 (Advanced, option 1)", "title"),
    ("", None),
    ("!! The ball-by-ball rows are ILLUSTRATIVE simulated data (seeded random), NOT a real match. Replace them with your own observed data before submitting. !!", "warn"),
    ("", None),
    ("How to use", "h"),
    ("1. Watch an innings of a T20 match and pick 3 fielders. Type their names in Performance_Matrix (blue cells A17:A19).", None),
    ("2. In Ball_by_Ball record every ball (one row per ball). Rows with no fielding action can keep Player Name blank.", None),
    ("3. Use the drop-downs in the Pick and Throw columns. Formulas read rows 2-1000, so a full 120-ball innings fits easily.", None),
    ("4. Performance_Matrix updates automatically (counts, Performance Score, rates, phase analysis, chart).", None),
    ("", None),
    ("Codes (same as IPL_sample_data.xlsx)", "h"),
    ("Pick:  Y = Clean Pick | N = Fumble | C = Catch | DC = Dropped Catch | S = Stumping", None),
    ("Throw: Y = Good Throw | N = Bad Throw | DH = Direct Hit (batter safe) | RO = Run Out | MR = Missed Run Out", None),
    ("Runs:  + = runs saved, - = runs conceded by the fielding effort", None),
    ("Assumption: a direct hit that dismisses the batter is coded RO (not DH); DH is only for direct hits where the batter survives.", None),
    ("", None),
    ("Formula", "h"),
    ("PS = CP*1 + GT*1 + C*3 + DC*(-3) + ST*3 + RO*3 + MRO*(-2) + DH*2 + RS    (weights taken from the sample file; editable in Performance_Matrix B5:B12)", None),
    ("Formula_Check re-computes the 7 worked examples from the sample file and confirms the formula reproduces all of them.", None),
]
for i, (text, kind) in enumerate(lines, 1):
    c = ins.cell(i, 1, text)
    c.font = Font(name=FONT, bold=kind in ("title", "h"), size=14 if kind == "title" else 10,
                  color="C00000" if kind == "warn" else "000000")
    c.alignment = Alignment(wrap_text=True, vertical="top")
ins.column_dimensions["A"].width = 130

wb.save("cricket_fielding_analysis.xlsx")
print("saved")
